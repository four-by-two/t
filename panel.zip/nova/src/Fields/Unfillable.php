<?php

namespace Laravel\Nova\Fields;

/**
 * @mixin \Laravel\Nova\Fields\Field
 */
interface Unfillable
{
    //
}
