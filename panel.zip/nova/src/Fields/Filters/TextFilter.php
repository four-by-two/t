<?php

namespace Laravel\Nova\Fields\Filters;

class TextFilter extends Filter
{
    /**
     * The filter's component.
     *
     * @var string
     */
    public $component = 'text-field';
}
