<?php

namespace Laravel\Nova\Fields\Filters;

class BooleanGroupFilter extends Filter
{
    /**
     * The filter's component.
     *
     * @var string
     */
    public $component = 'boolean-group-field';
}
