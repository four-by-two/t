// import {{ class }} from './components/{{ class }}'

// Nova.booting(app => {
//   app.component('{{ name }}', {{ class }})
// })
