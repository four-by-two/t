<?php

namespace Laravel\Nova\Contracts;

/**
 * @method \Illuminate\Http\Response toDownloadResponse(\Laravel\Nova\Http\Requests\NovaRequest $request, \Laravel\Nova\Resource $resource)
 *
 * @mixin \Laravel\Nova\Fields\Field
 */
interface Downloadable
{
    //
}
