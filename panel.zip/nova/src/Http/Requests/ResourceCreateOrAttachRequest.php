<?php

namespace Laravel\Nova\Http\Requests;

class ResourceCreateOrAttachRequest extends NovaRequest
{
    //
}
