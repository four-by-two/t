<?php

namespace Laravel\Nova\Http\Requests;

class ResourcePeekRequest extends NovaRequest
{
    //
}
